<p align="center">
  <img src="docs/icon.png" width="120" alt="Soro icon">
</p>

<h1 align="center">Soro</h1>
<p align="center"><b>A free, all-in-one gaming PC optimizer for Windows 10 &amp; 11 - desktops and laptops.</b><br>
More FPS, less lag, a cleaner Windows. Every change is backed up and can be undone.</p>

<p align="center">
  <a href="../../releases/latest"><b>Download the latest version</b></a>
</p>

---

## Download & run

1. Go to [**Releases**](../../releases/latest) and download **`Soro.exe`**.
2. Put it in its own folder, for example `C:\Soro`.
3. Double-click it and click **Yes** when Windows asks for admin rights.

Windows SmartScreen may say *"Windows protected your PC"* because Soro is not code-signed yet - click **More info > Run anyway**.

> **Antivirus warnings:** some antivirus tools (for example Malwarebytes) flag Soro by mistake, because a tool that changes system settings, removes apps and cleans files *looks* like malware to automatic scanners. If your antivirus quarantines it, restore it and add the Soro folder to its allow list.

## Free and Pro

Soro is **free**. **Soro Pro** unlocks everything marked PRO in the app - all the Gamer and Extreme tweaks, GPU Boost, Fortnite Boost, Auto Game Mode, deep RAM clean, the fastest-DNS switch, Deep Clean and one-click driver installs.

**To get Pro:** open Soro → **Settings → Soro Pro**, copy your **PC ID** and send it to `Solro4` on Discord. You get a key back - paste it in and press **Activate**. The key works on your PC only.

## What it does

| Page | What you get |
|---|---|
| **Home** | PC Checkup that finds problems and fixes them in one click, live CPU / RAM / disk, and **Optimize my PC** |
| **Optimize** | 56 tweaks in 3 presets (Safe, Gamer, Extreme): power, timers, game priority, input lag, graphics card, network, telemetry, ads, debloat. Each tweak shows how much it really does (High / Medium / Small impact). Shows which are already active and hides tweaks that don't suit your PC |
| **GPU Boost** | NVIDIA and AMD: live GPU load, temperature, video memory and clock speed; finds monitors stuck below their max refresh rate (e.g. a 144 Hz screen running at 60 Hz) and fixes them in one click; NVIDIA driver settings (Prefer maximum performance, Low Latency Mode, highest refresh rate), MSI interrupt mode, telemetry off, AMD background extras off, Multiplane Overlay flicker fix |
| **Game Mode** | One button (or fully automatic): closes background apps, clears RAM, max power, pauses Windows Update, gives your game High priority and your best GPU. **Full clean** (Pro) closes *everything* in the background like Task Manager - keeping Discord, your keep list, your game + anti-cheat and your hardware software - and brings tray apps back afterwards |
| **Game Boost** | **Ping Doctor** (free): tests your own line, Gulf game servers, Wi-Fi, VPNs and apps using your internet, then tells you exactly what to fix. **Game profiles** (Pro) for 12 games - Roblox, Fortnite, VALORANT, CS2, Apex, Minecraft and more: High priority every launch, game traffic first, best in-game settings |
| **Fortnite Boost** (Pro) | Competitive preset (Performance mode, max FPS, FPS cap matched to your monitor) or Balanced, High priority, fullscreen optimizations off - with one-click restore |
| **RAM Cleaner** | Clears cached RAM (like ISLC) to stop stutters, deep clean, auto clean, and the apps using the most RAM |
| **Network Boost** | Speed test with a lag-under-load grade (bufferbloat), Wi-Fi / cable checkup, ping to game-server regions, fastest DNS in one click, QoS game priority, "Fix my internet" |
| **Drivers** | Finds missing or broken drivers, checks your graphics driver age, installs driver updates from Windows Update, backs up drivers |
| **Startup Apps** | Turn off apps that slow down boot |
| **Storage** | Junk cleaner, **Smart Deep Clean** (update leftovers, old restore points, old drivers, Windows.old, old Roblox versions...), big file finder, apps & games by size, folder size explorer |
| **Benchmark** | Measures your PC before and after optimizing so you can see what improved |
| **Settings** | Tray icon, start with Windows, Auto Game Mode, **auto-update**, and Soro's own RAM use |

Works on laptops too: power tweaks only apply while plugged in, battery-draining tweaks are switched off, and you get battery warnings before gaming.

## Updates

Soro checks this repo's [Releases](../../releases) when it opens and every 6 hours. New versions download, get checked against GitHub's SHA-256 checksum, and install themselves (never during Game Mode). To publish an update: create a release tagged `vX.Y.Z` (higher than the current one) with `Soro.exe` attached.

## Safe by design

- **Every setting is backed up** before Soro changes it. *Revert* or *Undo everything* on the Optimize page puts it back exactly. Soro also makes a **System Restore point** first.
- **Never touched:** Windows Update, Windows Security / Defender, Microsoft Store, Xbox apps & Game Bar, Edge (Windows needs it), audio, Wi-Fi, Bluetooth, Camera, Photos, Calculator, Notepad, Paint, Snipping Tool.
- Tweaks that lower security (like turning off Memory Integrity) are only in **Extreme**, clearly labelled, and Soro asks before applying them.
- Removed apps can be reinstalled from the Microsoft Store.

## How it's built

- Soro is one PowerShell + WPF app (no install, no extra downloads). Heavy work runs on background threads so the window never freezes.
- `Soro.exe` is a tiny launcher that runs the app inside its own process, with Soro's icon and an admin manifest.
- NVIDIA settings are changed through NVIDIA's own driver API (NVAPI), inside Soro - no extra programs are created on your PC.
- Settings and backups live in `C:\ProgramData\Soro`.

Requirements: Windows 10 or 11 (64-bit) and .NET Framework 4.8 (built into both).

## Disclaimer

Soro changes Windows settings. It backs everything up and has been designed to be safe, but you use it at your own risk - there is no warranty.
